# Package Manifest: AIML-MRMS IJSE Final Supporting Package

## Package Role

This ZIP supports the IJSE-reframed AIML-MRMS manuscript. It combines the corrected computational evidence package with a short Word supporting document that explains the methodology reframing and evidence boundaries.

## File Inventory

| File | Role | SHA-256 |
|---|---|---|
| `AIML_MRMS_IJSE_Supporting_Document.docx` | Word supporting document explaining the IJSE pathway, methodology contribution, evidence calibration, Table 8/9 decision, and generalisability boundary. | `d9449cfe5c376a4993cd7a4bb1f782e76bfc78884b2c781a4ffea7afd184b19a` |
| `AIML_MRMS_Supporting_Documents_CORRECTED_v1_1.zip` | Corrected computational support package reproducing corrected manuscript evidence and audit notes. | `eb619d5b5fb3d9ee02456193d73adfd1323cc0882bc0649108eddb129d0b768d` |
| `README_IJSE_SUPPORT_PACKAGE.md` | Package-level explanation for editors and reviewers. | `46a1ada7d10e2bfe86f5088b29cfc396a0765f668bf70302fd8255ae49386e25` |

## Manuscript Evidence Alignment

| Manuscript item | Support location | Evidence status |
|---|---|---|
| Table 5: SVM LOO-CV metrics | Corrected computational ZIP, `results/tables/table5_svm_loo_metrics.csv` | Retained |
| Table 6: feature-weight mapping | Corrected computational ZIP, `results/tables/table6_svm_feature_weights.csv` and `table6_aggregated_criterion_weights.csv` | Retained |
| Table 7: corrected TOPSIS values | Corrected computational ZIP, `results/tables/table7_topsis_results.csv` | Retained |
| Table 8: baseline PCI/RPCI diagnostic | Corrected computational ZIP, `results/tables/baseline_pci_rpci.csv` | Retained as diagnostic only |
| Table 9: qualitative architecture comparison | Word supporting document | Retained as qualitative comparison only |
| Former Table 8/9 delta-PCI benchmark | Corrected computational ZIP, audit notes and README | Withdrawn |

## Submission Note

This package should be used with the revised manuscript only. It does not support claims of algorithmic novelty, broad empirical generalisability, or proven performance superiority. It supports a methodology/architecture contribution demonstrated through a corrected proof-of-concept.
