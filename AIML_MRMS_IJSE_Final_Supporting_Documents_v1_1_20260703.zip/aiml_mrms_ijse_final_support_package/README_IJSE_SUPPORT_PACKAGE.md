# AIML-MRMS IJSE Final Supporting Package

This package supports the IJSE-reframed manuscript:

**A Governance-Aware Sustainable Engineering Decision Methodology for Mineral Resource Management: An Adaptive AI-MCDM-Optimisation Architecture**

## Purpose

The package documents the corrected evidence base and the revised methodological positioning used in the IJSE pathway. It supports AIML-MRMS as a governance-aware sustainable engineering decision methodology and architecture, not as a new SVM, AHP, TOPSIS, or optimisation algorithm.

## Package Contents

1. `AIML_MRMS_IJSE_Supporting_Document.docx`
   - Explains the IJSE reframing pathway.
   - Clarifies the methodology/architecture contribution.
   - Calibrates evidence claims against the corrected results.
   - States how Tables 8 and 9 should be interpreted in the revised manuscript.

2. `AIML_MRMS_Supporting_Documents_CORRECTED_v1_1.zip`
   - Contains the corrected computational support package.
   - Reproduces corrected Table 5, Table 6, Table 7, and baseline PCI/RPCI outputs.
   - Includes the audit notes withdrawing the earlier cross-configuration PCI/RPCI benchmark claims.

3. `PACKAGE_MANIFEST_IJSE_FINAL_SUPPORT.md`
   - Lists the package contents and their manuscript role.

## Evidence Boundary

The revised manuscript retains:

- Table 5: Linear SVC proof-of-concept validation metrics.
- Table 6: SVM feature-importance mapping into AHP criteria.
- Table 7: Corrected TOPSIS results across adaptive-update cycles.
- Table 8: Baseline PCI/RPCI diagnostic values only.
- Table 9: Qualitative architecture comparison only.

The revised manuscript does not retain the former Table 8/9 cross-configuration delta-PCI benchmark as evidence. Earlier numerical claims such as `NGA delta-PCI = +0.030` and `ZAF delta-PCI = +0.017` are withdrawn from the manuscript pathway.

## Recommended Use

Submit this package as the final supporting-document ZIP for the IJSE-reframed manuscript. The package is designed to make the manuscript's contribution and evidence boundary clear to editors and reviewers.
